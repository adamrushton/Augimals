﻿public class testscore : UnityEngine.MonoBehaviour
{

    int score = 50;
    int gameModeNumber = 3; // Game mode 3 has finished
	// Use this for initialization
	void Start()
    {
        UnityEngine.PlayerPrefs.SetInt("GameModeNumber", gameModeNumber); // Store game mode number in playerprefs
        UnityEngine.PlayerPrefs.SetInt("FinalScore"+gameModeNumber, score);
	}
	
    public void LoadProgressionScene()
    {
        try
        {
            UnityEngine.SceneManagement.SceneManager.LoadScene("ProgressionScores"); // Will change to +gameModeNumber
        }
        catch (System.Exception e)
        {
            UnityEngine.Debug.Log(e.Message);
        }
    }
}
